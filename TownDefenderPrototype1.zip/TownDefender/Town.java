import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Town extends World
{
    private Counter hpCounter;
    private Counter moneyCounter;
    
    private int roundCount;
    
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public Town()
    {    
        // Create a new world with 1200x800 cells with a cell size of 1x1 pixels.
        super(1200, 800, 1); 
        hpCounter = new Counter("HP:",100);
        moneyCounter = new Counter("Money:",750);
        
        placeObjects();
        
        addObject(hpCounter,50,780);
        addObject(moneyCounter,50,20);
        
    }
   
    public void placeObjects()
    {
        häuserLinie(true);
        häuserLinie(false);
        placePonds(2,true);
        placePonds(2,false);
        placeStreet(10);
    }
    public void häuserLinie(boolean oben)
    {
        int x = 0;
        int y = 0;
        if(oben)
         y = 300;
        else
        {
            y = 500;
        }
        for(int i = 0; i < 20; i++)
        {
            Haus haus = new Haus();
            x = 60 * i + 10;
            addObject(haus,x,y);
        }
    }
    public void placePonds(int howMany, boolean oben)
    {
        int x = 0;
        int y = 0;
        if(oben)
         y = 150;
        else
        {
            y = 690;
        }
        for(int i = 0; i < howMany; i ++)
        {
            Pond pond = new Pond();
            x = 400 * i + 400;
            addObject(pond,x,y);
        }
    }
    public void placeStreet(int howMany)
    {
        for(int i = 0;i < howMany; i++)
        {
            Pathway street = new Pathway();
            int x = 133 * i;
            int y = 400;
            addObject(street,x,y);
        }
    }
    
    public void loseHp(int howMany)
    {
         hpCounter.loseValue(howMany);
    }
    public void getHp(int howMany)
    {
        hpCounter.addValue(howMany);
    }
}
