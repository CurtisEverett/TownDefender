
public class Debuff
{
    private double damageBuff;
    private double attackSpeedBuff;
    private int moneyBuff;
    private double movementSpeedBuff;

    public Debuff()
    {
    }
    
    public Debuff getBuff(){return this;}
    
    
}
